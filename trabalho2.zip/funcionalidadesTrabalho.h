#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <sys/stat.h>
#include <ctype.h>

//funcoes de 1 a 8
int leVeiculos(); //1
int leLinhas(); // 2
int listaVeiculos(); //3 
int listalinhas(); // 4
int buscaVeiculo(); //5
int buscaLinha(); //6
int insereVeiculos(); //7
int insereLinhas(); //8

int criaArvoreVeiculos(); //9
int criaArvoreLinhas(); //10 
int buscaArvoreVeiculos(); //11
int buscaArvoreLinhas(); //12
int insereVeiculosArvore(); //13
int insereLinhasArvore(); //14