#ifndef _criaArvoreVeiculos_

#define _criaArvoreVeiculos_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "./arvore-b.h"
#include "./insercao.h"
#include "../veiculos.h"



#endif