#ifndef _criaArvoreVeiculos_

#define _criaArvoreVeiculos_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "./arvore-b.h"
#include "./insercao.h"
#include "../veiculos.h"

void insereChaveEmArvoreNova(FILE* fb, CabecalhoArvore* cabecalhoArvore, Chave* chave) {
    
    NoArvore* noRaiz = (NoArvore*) malloc(sizeof(NoArvore));
    inicializaNoArvore(noRaiz, '0', cabecalhoArvore);
    noRaiz->RRNdoNo = cabecalhoArvore->noRaiz;
    
    //se o nó raiz sofreu split, é preciso criar nova raiz
    int houveSplitNoAtual = desceNaArvore(fb, noRaiz, chave, cabecalhoArvore);
    
    if (houveSplitNoAtual != 0) {
    
        //cria nova raiz
        int RRNRaizAntiga = noRaiz->RRNdoNo;
        inicializaNoArvore(noRaiz, '0', cabecalhoArvore);
        noRaiz->P1 = RRNRaizAntiga;
        noRaiz->C1 = chave->C;
        noRaiz->Pr1 = chave->Pr;
        noRaiz->P2 = chave->P; //guarda o nó criado no split

        noRaiz->RRNdoNo = cabecalhoArvore->RRNproxNo;
        cabecalhoArvore->RRNproxNo++;
        cabecalhoArvore->noRaiz = noRaiz->RRNdoNo;
        noRaiz->nroChavesIndexadas++;
        
        //pulamos para o nó onde houve a inserção e escrevemos no disco
        int byteOffsetNoArvore = TAM_PAG_DISCO*(1+ noRaiz->RRNdoNo);
        
        //pulamos para o nó a ser escrito
        fseek(fb, byteOffsetNoArvore, SEEK_SET);
        writeNoArvore(fb, noRaiz, cabecalhoArvore);  

    }
    
    free(noRaiz);
}

int desceNaArvore(
    FILE* fb,
    NoArvore* noArvore,
    Chave* chave,
    CabecalhoArvore* cabecalhoArvore)
{
    
    //pulamos para o nó a ser lido e lemos para a RAM
    int byteOffsetNoArvore = TAM_PAG_DISCO*(1+ noArvore->RRNdoNo);
    fseek(fb, byteOffsetNoArvore, SEEK_SET);
    readNoArvore(fb, noArvore);

    //flag que indicará se houve split no nó atual
    int houveSplitNoAtual = 0;

    int RRNNoBusca = -3;
        
    if(chave->C < noArvore->C1) {
        RRNNoBusca = noArvore->P1;
    }
    else if (chave->C < noArvore->C2 || noArvore-> C2 == -1) {
        RRNNoBusca = noArvore->P2;
        
    }
    else if (chave->C < noArvore->C3 || noArvore-> C3 == -1) {
        RRNNoBusca = noArvore->P3;
    }
    else if (chave->C < noArvore->C4 || noArvore-> C4 == -1) {
        RRNNoBusca = noArvore->P4;
    }
    else {
        RRNNoBusca = noArvore->P5;
    }
    //apenas para debug. Significa que não conseguiu relacionar qual chave era maior de forma correta
    // if (RRNNoBusca == -3) {
    //     printf("ERRO DE COMPARAÇÃO DE CHAVES!\n");
    // }

    // se o nó não for folha, faz a busca pelo nó folha
    if(noArvore->folha != '1') {
        
        //verifica possível erro no programa
        // if(RRNNoBusca == -1) {
        //     printf("ERRO: está tratando como folha");
        // }
        
        //cria nó vazio, que lerá o conteúdo do filho
        NoArvore* noFilho = (NoArvore*) malloc(sizeof(NoArvore));
        inicializaNoArvore(noFilho, '0', cabecalhoArvore);
        noFilho->RRNdoNo = RRNNoBusca;
        
        //flag que indica se uma chave foi promovida
        int houveSplitNoFilho = desceNaArvore(fb, noFilho, chave, cabecalhoArvore);
        
        if (houveSplitNoFilho != 0) {
            //insere a chave a ser promovida no nó atual, não no filho
            houveSplitNoAtual = insereChave(fb, noArvore, chave, cabecalhoArvore, RRNNoBusca);
            
        }
    }
 
    //se for folha, insere 
    else{
        //se a inserção retornar um split, quer dizer que é preciso inserir a chave promovida no nó atual
        houveSplitNoAtual = insereChave(fb, noArvore, chave, cabecalhoArvore, RRNNoBusca);        
    }

    return houveSplitNoAtual;
}

#endif